import java.util.InputMismatchException;
import java.util.Scanner;
//para que nos funcione la lectura de variables


public class Examen {
    public void ejercicio1() {
        double num1 = 0;
        int resultado;

        try {
            Scanner hola = new Scanner(System.in);


            System.out.println("Introduce un numero:");
            num1 = hola.nextDouble();

            if (num1 < 0) {
                resultado = (int) (num1 * 1);
                System.out.println("Valor absoluto es " + num1 * -1);
            } else {

                System.out.println("Valor absoluto es " + num1);
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Debes ingresar un número entero.");
        }


    }


    public void ejercicio2() {

        Scanner ejer2 = new Scanner(System.in);

        System.out.print("Introduce tu nombre: ");
        String nombre = ejer2.nextLine();

        System.out.println("La obre de " + nombre);

        System.out.println("Introduce el ancho de la pared:");
        int anchop = ejer2.nextInt();

        System.out.println("Introduce el largo de la pared:");
        int largop = ejer2.nextInt();

        System.out.println("Introduce el ancho del azulejo:");
        int anchoa = ejer2.nextInt();

        System.out.println("Introduce el largo del azulejo:");
        int largoa = ejer2.nextInt();

        if (anchop < largop) {
            System.out.println("El azulejo no puede ser cuadrado");
        }

        if (largoa > largop) {
            System.out.println("El azulejo no puede ser más grande que la pared");
        } else {
            int azulejo = largop * largoa;
            System.out.println("Se necesitan " + azulejo + " azulejos.");
        }


    }
}




