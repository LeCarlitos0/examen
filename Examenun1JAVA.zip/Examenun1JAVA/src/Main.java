import java.util.Scanner;
public class Main {
    public static void main(String[] args)
    {

        //Examen carlos1 = new Examen();
        //carlos1.ejercicio1();

        Examen carlos2 = new Examen();
        carlos2.ejercicio2();

    }
}